<!doctype html>
<html>
<head>
	<title>Info wisata</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>

<body>
	<a href="#adminpanel.php">Login</a>
	<header>
		<br>
		<br>
		<h1 class="judul">Info Wisata Daerah Istimewa Yogyakarta</h1>
		<p class="deskripsi">Info tempat wisata yang menarik dan asik dikunjung di JOGJA</p>
	</header>
<!-- <div class="wrap">
	<nav class="menu"> -->
			<ul>
				<li><a class="active" href="index.php">Home</a></li>
				<li><a href="profil.php">Profile</a></li>
				<li><a href="Aksesoris.php">Aksesoris</a></li>
				<li><a href="Batik.php">Batik</a></li>
				<li><a href="Makanan.php">Makanan</a></li>
				<li><a href="dokumentasi.php">Dokumentasi</a></li>
				<li><a href="kontak.php">Hubungi Kami</a></li>
			</ul>

		<marquee width="95%" loop="infinite">Running Text Informasi Terkini ● Running Text Informasi Terkini ● Running Text Informasi Terkini ● Running Text Informasi Terkini ● Running Text Informasi Terkini ● Running Text Informasi Terkini ● </marquee>
		<aside class="sidebar">
			<div class="widget">
				<h2>Potensi Wisata</h2>
				<p>Alam, budaya dan nilai artistik yang ada di Daerah Istimewa Yogyakarta merupakan harta yang tak tenilai, Sejalan denganperkembangan jaman dan kebutuhan manusia untuk bersenang-senang, bersantai dan memenuhi hasrat untuk menambah pengetahuan dan pengalaman...</p>
			</div>

			<div class="widget">
				<h2>Video Potensi Wisata</h2>
				
			</div>
		</aside>
		<section class="courses">
			<article>
				<b><p align="center">Alamat  : Trini, Trihanggo, Gamping, Sleman<br>
				No Telp : 087836934895<br>
				Email 	:infowisata@gmail.com<br></p></b>
			</article>   
		</section>
	</div>
</body>
</html>