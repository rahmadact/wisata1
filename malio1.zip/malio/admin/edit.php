<!DOCTYPE html>
<html>
<head>
	<title>edit</title>
</head>
<body>
	<a href="index.php">Lihat Semua Data</a>

	<br/>
	<h3>Edit data</h3>

	<?php 
	include "koneksi.php";
	$id = $_GET['id_artikel'];
	$query= mysqli_query($connect,"SELECT * FROM artikel WHERE id_artikel='$id'")or die(mysqli_error());
	$nomor = 1;
	while($data = mysqli_fetch_array($query)){
	?>
	<form action="update.php" method="post">		
		<table>
			<tr>
				<td>Judul Artikel</td>
				<td>
					<input type="hidden" name="id_artikel" value="<?php echo $data['id_artikel'] ?>">
					<input type="text" name="judul_artikel" value="<?php echo $data['judul_artikel'] ?>">
			  </td>					
			</tr>	
			<tr>
				<td>Isi Artikel</td>
				<td><input type="text" name="isi_artikel" value="<?php echo $data['isi_artikel'] ?>"></td>					
			</tr>	
			<tr>
				<td>Penulis Artikel</td>
				<td><input type="text" name="penulis_artikel" value="<?php echo $data['penulis_artikel'] ?>"></td>					
			</tr>
			<tr>
				<td>Photo Artikel</td>
				<td><input type="file" name="images" value="<?php echo $data['photo_artikel'] ?>"></td>					
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" value="Simpan"></td>					
			</tr>				
		</table>
	</form>
	<?php } ?>
</body>
</html>