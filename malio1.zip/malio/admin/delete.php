<?php
include 'koneksi.php';
$id_artikel   = $_GET['id_artikel'];
$query="DELETE from artikel where id_artikel='$id_artikel'";
mysqli_query($connect, $query);
header("location:index3.php");
?>