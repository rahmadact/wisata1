<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Admin Panel Login</title>
	<link href="style1.css" rel="stylesheet" type="text/css">
</head>

<body>
	<form name="login" class="login" action="proses_login.php" method="post">
		
		<input placeholder="username" type="text" name="username"><br>
		<input placeholder="Password" type="password" name="pass"><br>
		<input type="submit" align="center">
	</form>
</body>
</html>