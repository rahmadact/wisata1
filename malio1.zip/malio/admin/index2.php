<?php 
include('koneksi.php'); ?>
<html>
<head>
	<title>Admin Area</title>
</head>
<body>
 
	<div style="text-align:center">
		<h2>Admin Area</h2>
		<p><a href="index2.php">Home</a> / <p><a href="formartikel.php">Insert data</a> / <p><a href="index3.php">Update dan delete</a></p> / <a href="logout.php">Logout</a></p>
 
		<p>Selamat datang di Admin Area</p>
	</div>
 
</body>
</html>