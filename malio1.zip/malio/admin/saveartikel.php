<?php ob_start();
include "koneksi.php";
if($_POST){
 $judulartikel      = $_POST['judul_artikel'];
 $isiartikel      = $_POST['isi_artikel'];
 $penulisartikel  = $_POST['penulis_artikel'];
 $photoartikel   = $_FILES['images']['name'];
 
 if(!empty($_FILES['images']['tmp_name'])){
  move_uploaded_file($_FILES['images']['tmp_name'],'photo-artikel/'.$_FILES['images']['name']);

  $sql=mysqli_query($connect,"insert into artikel(judul_artikel,isi_artikel,penulis_artikel,photo_artikel)
  values('$judulartikel','$isiartikel','$penulisartikel','$photoartikel')"); 
  
 } else {
  $sql=mysqli_query($connect,"insert into artikel(judul_artikel, isi_artikel, penulis_artikel)
  values('$judulartikel','$isiartikel','$penulisartikel')");
  
 }
 if($sql==true)
 {
    header('location:../index.php');
 }
 else
 {
     echo "gagal";
     header("location:formartikel.php");
 }

 exit;
}

?>
