<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>login</title>
	<link href="style1.css" rel="stylesheet" type="text/css">
</head>

<body>
	<form name="login" class="login" action="cek_login.php" method="post">
		<input placeholder="username" type="text"><br>
		<input placeholder="Password" type="password"><br>
		<input type="submit" align="center">
	</form>
</body>
</html>