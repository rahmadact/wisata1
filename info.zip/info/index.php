<!doctype html>
<html>
<head>
<title>Info wisata</title>
<link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>
<header>
		<h1 class="judul">Info Wisata Daerah Istimewa Yogyakarta</h1>
		<p class="deskripsi">Info tempat wisata yang menarik dan asik dikunjung di JOGJA</p>
	</header>
<div class="wrap">
	<nav class="menu">
		<ul>
         <li><a href="#">Home</a></li>
         <li><a href="daftar_pantai.php">Pantai</a></li>
         <li><a href="daftar_alam.php">Alam</a></li>
         <li><a href="daftar_kota.php">kota</a></li>
      	 <li><a href="admin/index.php">Login Admin</a></li>
         </ul>
	</nav>
<aside class="sidebar">
			<div class="widget">
				<h2>Info</h2>
				<p>Selamat datang di Infowisatajogja.com, situs ini menyediakan info seputar tempat wisata di jogja.</p>
			</div>
  </aside>

</div>
</body>
</html>