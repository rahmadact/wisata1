<?php
$host       = "localhost";
$user       = "root";
$password   = "";
$database   = "wisata";
$connect    = mysqli_connect($host, $user, $password, $database);
?>