<?php  

$server= "localhost";  
$username = "root";   
$password = "";   
$database = "wisata";   
$connect=mysqli_connect($server,$username,$password) or die ("Koneksi Gagal");  
mysqli_select_db($connect,$database) or die ("Database Tidak Bisa Di Buka " );  
?>