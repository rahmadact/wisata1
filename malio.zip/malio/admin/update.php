<?php 

include 'koneksi.php';
$id_artikel = $_POST['id_artikel'];
$judul_artikel = $_POST['judul_artikel'];
$isi_artikel = $_POST['isi_artikel'];
$penulis_artikel = $_POST['penulis_artikel'];
$photo_artikel = $_FILES['images']['name'];
mysqli_query($connect,"UPDATE artikel SET judul_artikel='$judul_artikel', isi_artikel='$id_artikel', penulis_artikel='$penulis_artikel', photo_artikel='$photo_artikel' WHERE id_artikel='$id_artikel'");

header("location:index3.php?pesan=update");
?>