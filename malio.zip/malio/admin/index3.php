<!DOCTYPE html>
<html>
    <head>
        <title>Update dan delete</title>
    </head>
    <body>
        <h2>List Artikel</h2>
        <table border="1">
            <tr><th>NO</th><th>judul</th><th>isi</th><th>penulis</th><th>photo</th><th>ACTION</th></tr>
            <?php
            include 'koneksi.php';
            $artikel = mysqli_query($connect, "SELECT * from artikel");
            $no = 1;
            foreach ($artikel as $row) {
              
                echo "<tr>
            <td>$no</td>
            <td>" . $row['judul_artikel'] . "</td>
            <td>" . $row['isi_artikel'] . "</td>
            <td>" . $row['penulis_artikel'] . "</td>
            <td>" . $row['photo_artikel'] . "</td>
            <td><a href='edit.php?id_artikel=$row[id_artikel]'>Edit</a>
                <a href='delete.php?id_artikel=$row[id_artikel]'>Delete</a>
            </td>
              </tr>";
                $no++;
            }
            ?>
        </table>

    </body>
</html>