<?php
include "koneksi.php";
$username = $_POST['username'];
$password =$_POST['pass'];
$login    = mysqli_query($connect, "select * from admin where username='$username' and pass='$password'");
$result   = mysqli_num_rows($login);
if($result>0){
header("location:index2.php");
}else
{
	header("location:index.php");
}
?>