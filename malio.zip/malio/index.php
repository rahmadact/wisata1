﻿<!doctype html>
<html>
<head>
	<title>Info wisata Maliboro</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>

<body>
	<header>
		<h1 class="judul">Info Wisata Maliboro</h1>
		<p class="deskripsi">Info Wisata yang asik dan menarik di Maliboro</p>
	</header>
<!-- <div class="wrap">
	<nav class="menu"> -->
			<ul>
			<li><a class="active" href="index.php">Home</a></li>
			<li><a href="profil.php">Profile</a></li>
			<li><a href="Aksesoris.php">Aksesoris</a></li>
			<li><a href="Batik.php">Batik</a></li>
			<li><a href="Makanan.php">Makanan</a></li>
			<li><a href="dokumentasi.php">Dokumentasi</a></li>
			<li><a href="kontak.php">Hubungi Kami</a></li>
			</ul>

		<marquee width="95%" loop="infinite">Running Text Informasi Terkini ● Running Text Informasi Terkini ● Running Text Informasi Terkini ● Running Text Informasi Terkini ● Running Text Informasi Terkini ● Running Text Informasi Terkini ● </marquee>
		<aside class="sidebar">
			<div class="widget">
				<h2>Potensi Wisata</h2>
				<p>Alam, budaya dan nilai artistik yang ada di Daerah Istimewa Yogyakarta merupakan harta yang tak tenilai, Sejalan denganperkembangan jaman dan kebutuhan manusia untuk bersenang-senang, bersantai dan memenuhi hasrat untuk menambah pengetahuan dan pengalaman...</p>
			</div>

			<div class="widget">
				<h2>Video Potensi Wisata</h2>
				
			</div>
		</aside>
		<section>
			<p class="ribbon">Berita Terbaru</p>
		</section>
		<section class="courses">
<?php
include "admin/koneksi.php";
$has = mysqli_query($connect,"select * from artikel order by tgl_artikel desc");
$num = mysqli_num_rows($has);

if($num<1){
 echo'<center>Tidak Ada Artikel</center>';
}
else
{
	while ($data=mysqli_fetch_array($has))
	{
		$art = substr($data['isi_artikel'],0,100);
		echo '<h2>'.$data['judul_artikel'].'</h2>';
		echo '<img width="330" height="280" src="admin/photo-artikel/'.$data['photo_artikel'].'">';
		echo '<h4>Di publikasikan pada '.$data['tgl_artikel'].'</h4>';
		echo '<h4>Oleh '.$data['penulis_artikel'].'</h4>';
		echo '<p>'.$art.'..</p>
				<a href="single.php?p='.$data['id_artikel'].'">Read More</a>
			<br><br>';
	}
}
?>        
		</section>
	</div>
</body>
</html>